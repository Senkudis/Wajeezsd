// Service Worker for Wassili Delivery PWA - Final Fix
const CACHE_VERSION = 'v1.0.3'; // رفعت الرقم عشان المتصفح يحدث الكاش
const STATIC_CACHE = `wassili-static-${CACHE_VERSION}`;
const DYNAMIC_CACHE = `wassili-dynamic-${CACHE_VERSION}`;
const OFFLINE_PAGE = '/offline.html';

// Static assets to cache on install
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/style.css',
    '/logo.png',
    '/offline.html',
    '/icons/icon-192x192.png',
    '/icons/icon-512x512.png'
    // ضيف هنا أي ملفات تانية مهمة
];

// 1. Install Event
self.addEventListener('install', (event) => {
    console.log('[SW] Installing Service Worker...');
    self.skipWaiting(); // Force activation immediately
    event.waitUntil(
        caches.open(STATIC_CACHE).then((cache) => {
            console.log('[SW] Caching static assets');
            return cache.addAll(STATIC_ASSETS);
        })
    );
});

// 2. Activate Event (Cleanup)
self.addEventListener('activate', (event) => {
    console.log('[SW] Activating & Cleaning up...');
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                        console.log('[SW] Removing old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    return self.clients.claim();
});

// 3. Fetch Event (The Brain)
self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    // --- FILTERS (فلاتر الأمان) ---

    // 1. تجاهل أي رابط خارجي (الحل النهائي لمشكلة الصور الخارجية)
    // أي حاجة مش من موقعنا (localhost)، مالناش دعوة بيها
    if (!url.origin.includes(self.location.origin)) {
        return;
    }

    // 2. تجاهل أي طلب غير GET (يحل مشكلة POST Error)
    if (request.method !== 'GET') return;

    // 3. تجاهل طلبات socket.io (عشان التتبع المباشر)
    if (url.pathname.includes('socket.io')) return;

    // 4. تجاهل أي بروتوكول غير http/https
    if (!url.protocol.startsWith('http')) return;

    // --- STRATEGIES (الاستراتيجيات) ---

    // الاستراتيجية 1: Network First (للـ API والداتا المتغيرة)
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(request)
                .then((response) => {
                    // لو الرد سليم 100%، خزن نسخة منه
                    if (response && response.status === 200) {
                        const responseClone = response.clone();
                        caches.open(DYNAMIC_CACHE).then((cache) => {
                            cache.put(request, responseClone);
                        });
                    }
                    return response;
                })
                .catch(() => {
                    // لو النت قاطع، دور في الكاش
                    return caches.match(request).then((cachedResp) => {
                        if (cachedResp) return cachedResp;

                        // لو مش في الكاش، رجع رسالة JSON (أحسن من HTML للـ API)
                        return new Response(JSON.stringify({ error: 'Offline mode' }), {
                            headers: { 'Content-Type': 'application/json' }
                        });
                    });
                })
        );
        return;
    }

    // الاستراتيجية 2: Stale-While-Revalidate (للملفات والصور)
    event.respondWith(
        caches.match(request).then((cachedResponse) => {
            const fetchPromise = fetch(request).then((networkResponse) => {
                if (networkResponse && networkResponse.status === 200) {
                    const responseToCache = networkResponse.clone();
                    caches.open(STATIC_CACHE).then((cache) => {
                        try {
                            cache.put(request, responseToCache);
                        } catch (err) { }
                    });
                }
                return networkResponse;
            }).catch(() => {
                // فشل التحديث في الخلفية، مش مشكلة
            });

            return cachedResponse || fetchPromise;
        }).catch(() => {
            if (request.mode === 'navigate') {
                return caches.match(OFFLINE_PAGE);
            }
        })
    );
});