/**
 * نظام إشعارات وصل-لي الموحد
 * يدعم التنبيهات الصوتية، الـ Toasts العصرية، وتحديثات Socket.io
 */

const showToast = (title, message, type = 'info') => {
    // إنشاء حاوية التنبيهات إذا لم تكن موجودة
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
            z-index: 9999; width: 90%; max-width: 400px;
            display: flex; flex-direction: column; gap: 10px;
        `;
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const colors = {
        'order_accepted': '#3498db',
        'order_update': '#f39c12',
        'order_completed': '#27ae60',
        'chat': '#8e44ad',
        'info': '#0a8754'
    };

    const color = colors[type] || colors.info;

    toast.style.cssText = `
        background: white; border-right: 5px solid ${color};
        padding: 15px; border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1); display: flex; align-items: center;
        gap: 12px; animation: slideDown 0.5s ease-out; direction: rtl;
        cursor: pointer; position: relative;
    `;

    const icon = type.includes('order') ? 'bi-box-seam' : (type === 'chat' ? 'bi-chat-dots' : 'bi-bell');

    toast.innerHTML = `
        <div style="background:${color}22; padding:10px; border-radius:50%; color:${color}; display:flex; align-items:center; justify-content:center;">
            <i class="bi ${icon}" style="font-size:20px;"></i>
        </div>
        <div style="flex:1">
            <h4 style="margin:0; font-size:14px; font-weight:700; color:#333;">${title}</h4>
            <p style="margin:3px 0 0; font-size:12px; color:#666; line-height:1.4;">${message}</p>
        </div>
        <div style="position: absolute; bottom: 0; left: 0; height: 3px; background: ${color}44; width: 100%; animation: progress 4s linear forwards;"></div>
    `;

    // إضافة الأنيميشن
    if (!document.getElementById('toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.innerHTML = `
            @keyframes slideDown {
                from { transform: translateY(-100%); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            @keyframes fadeOut {
                to { opacity: 0; transform: translateY(-20px); }
            }
            @keyframes progress {
                from { width: 100%; }
                to { width: 0%; }
            }
        `;
        document.head.appendChild(style);
    }

    container.appendChild(toast);

    // إزالة التنبيه بعد 8 ثوانٍ (فترة كافية للقراءة)
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.5s forwards';
        setTimeout(() => toast.remove(), 500);
    }, 8000);

    toast.onclick = () => {
        // Detect if user is captain based on current URL
        if (window.location.href.includes('captain')) {
            window.location.href = 'captain-notifications.html';
        } else {
            window.location.href = 'notifications.html';
        }
    };

    playNotificationSound();
};

const initNotificationSocket = (userId) => {
    if (typeof io === 'undefined') return;
    const socket = io(window.API_BASE_URL || undefined);
    const cleanUserId = String(userId).trim();

    socket.on('connect', () => {
        socket.emit('user_join', cleanUserId);
        console.log('📡 Notification system active for:', cleanUserId);
    });

    socket.on('new_notification', (notification) => {
        showToast(notification.title, notification.message, notification.type);
    });

    socket.on('order_status_updated', (data) => {
        const statusMap = {
            'accepted': 'تم قبول طلبك! الكابتن في الطريق.',
            'picked_up': 'تم استلام طلبك بنجاح.',
            'delivered': 'تم توصيل طلبك، شكراً لك!',
            'cancelled': 'تم إلغاء الطلب.'
        };
        showToast('تحديث الطلب', statusMap[data.status] || 'تغيرت حالة طلبك', 'order_update');
        if (typeof loadOrders === 'function') loadOrders();
    });
};

function playNotificationSound() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(1046.50, audioCtx.currentTime + 0.1);
        gainNode.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.2);
    } catch (e) { }
}
