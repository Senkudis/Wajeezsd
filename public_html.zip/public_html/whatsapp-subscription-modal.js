/**
 * WhatsApp Subscription Modal - Rewritten with Smart Logic
 * Checks server-side subscription status before showing
 */

class WhatsAppSubscriptionModal {
    constructor() {
        this.modal = null;
        this.userPhone = null;
        this.pollingInterval = null;
        // 🔒 SECURED: API Key and URL removed. We now use the backend proxy.
    }

    /**
     * Get user's phone number from localStorage or DOM
     */
    getUserPhone() {
        // Try localStorage first
        const userStr = localStorage.getItem('user');
        if (userStr) {
            try {
                const user = JSON.parse(userStr);
                if (user.phone) {
                    console.log('✅ Phone found in localStorage:', user.phone);
                    return user.phone;
                }
            } catch (e) {
                console.error('Error parsing user from localStorage', e);
            }
        }

        // Fallback: Try to find phone in DOM (if available)
        const phoneInput = document.getElementById('userPhone') || document.querySelector('[data-user-phone]');
        if (phoneInput && phoneInput.value) {
            console.log('✅ Phone found in DOM:', phoneInput.value);
            return phoneInput.value;
        }

        console.log('❌ No phone number found');
        return null;
    }

    /**
     * Check if user is subscribed via API (Now checks via OUR Backend)
     */
    async checkSubscriptionStatus(phone) {
        try {
            // 🔒 Call our own backend instead of the Bot directly
            const response = await fetch(`/api/auth/check-subscription/${phone}`);

            if (response.ok) {
                const data = await response.json();
                return data.subscribed === true;
            }
        } catch (error) {
            console.error('⚠️ Error checking subscription:', error);
        }
        return false;
    }

    /**
     * Determine if modal should be shown
     */
    async shouldShow() {
        // Step 1: Get phone number
        this.userPhone = this.getUserPhone();

        if (!this.userPhone) {
            console.log('❌ Modal: No phone number available, cannot check subscription');
            return false;
        }

        // Step 2: Check server-side subscription status
        console.log(`📞 Checking subscription for: ${this.userPhone}`);
        const isSubscribed = await this.checkSubscriptionStatus(this.userPhone);

        if (isSubscribed) {
            console.log('✅ Modal: User is subscribed, hiding modal');
            return false;
        }

        console.log('⚠️ Modal: User is NOT subscribed');

        // Step 3: Check if user dismissed in this session
        const isDismissed = sessionStorage.getItem('whatsapp_prompt_dismissed');
        if (isDismissed) {
            console.log('❌ Modal: User dismissed it in this session');
            return false;
        }

        console.log('✅ Modal: Should show!');
        return true;
    }

    /**
     * Create modal HTML
     */
    create() {
        const modalHTML = `
            <div id="whatsapp-modal-overlay" style="
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.6);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
                animation: fadeIn 0.3s ease;
            ">
                <div style="
                    background: white;
                    border-radius: 20px;
                    padding: 40px 30px;
                    max-width: 450px;
                    width: 90%;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                    text-align: center;
                    animation: slideUp 0.3s ease;
                    direction: rtl;
                ">
                    <!-- WhatsApp Icon -->
                    <div style="
                        width: 80px;
                        height: 80px;
                        background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
                        border-radius: 50%;
                        margin: 0 auto 20px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="white">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                        </svg>
                    </div>

                    <!-- Title -->
                    <h2 style="
                        font-size: 24px;
                        font-weight: bold;
                        color: #333;
                        margin-bottom: 10px;
                        font-family: 'Cairo', sans-serif;
                    ">استقبل التحديثات فوراً!</h2>

                    <!-- Description -->
                    <p style="
                        color: #666;
                        font-size: 15px;
                        margin-bottom: 25px;
                        line-height: 1.6;
                        font-family: 'Cairo', sans-serif;
                    ">لاستقبال تحديثات الطلبات، ومرور التحقق على واتساب،<br>أرسل كلمة "اشتراك" إلى رقم الإشعارات</p>

                    <!-- Phone Number Box -->
                    <div style="
                        background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%);
                        border: 2px dashed #4CAF50;
                        border-radius: 12px;
                        padding: 20px;
                        margin-bottom: 25px;
                    ">
                        <div style="
                            color: #2E7D32;
                            font-size: 13px;
                            margin-bottom: 8px;
                            font-family: 'Cairo', sans-serif;
                        ">📱 رقم الإشعارات</div>
                        <div style="
                            font-size: 28px;
                            font-weight: bold;
                            color: #1B5E20;
                            letter-spacing: 2px;
                            direction: ltr;
                            font-family: 'Courier New', monospace;
                        ">+249112061302</div>
                        <div style="
                            color: #558B2F;
                            font-size: 12px;
                            margin-top: 8px;
                            font-family: 'Cairo', sans-serif;
                        ">يمكنك مسح رمز QR مباشرة أيضاً</div>
                    </div>

                    <!-- Buttons -->
                    <div style="display: flex; gap: 10px; flex-direction: column;">
                        <button id="whatsapp-subscribe-btn" style="
                            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
                            color: white;
                            border: none;
                            padding: 15px 30px;
                            border-radius: 12px;
                            font-size: 16px;
                            font-weight: bold;
                            cursor: pointer;
                            transition: all 0.3s;
                            font-family: 'Cairo', sans-serif;
                            box-shadow: 0 4px 15px rgba(37, 211, 102, 0.3);
                        " onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(37, 211, 102, 0.4)'"
                           onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(37, 211, 102, 0.3)'">
                            📲 افتح واتساب
                        </button>
                        
                        <button id="whatsapp-dismiss-btn" style="
                            background: transparent;
                            color: #999;
                            border: 2px solid #ddd;
                            padding: 12px 30px;
                            border-radius: 12px;
                            font-size: 14px;
                            cursor: pointer;
                            transition: all 0.3s;
                            font-family: 'Cairo', sans-serif;
                        " onmouseover="this.style.borderColor='#999'; this.style.color='#666'"
                           onmouseout="this.style.borderColor='#ddd'; this.style.color='#999'">
                            ربما لاحقاً
                        </button>
                    </div>
                </div>
            </div>

            <style>
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideUp {
                    from { transform: translateY(30px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            </style>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modal = document.getElementById('whatsapp-modal-overlay');
    }

    /**
     * Attach event listeners
     */
    attachEvents() {
        const subscribeBtn = document.getElementById('whatsapp-subscribe-btn');
        const dismissBtn = document.getElementById('whatsapp-dismiss-btn');

        // Subscribe button: Open WhatsApp and start polling
        subscribeBtn.addEventListener('click', () => {
            const whatsappUrl = 'https://wa.me/249112061302?text=اشتراك';
            window.open(whatsappUrl, '_blank');

            // Start polling to check if user subscribed
            this.startPolling();
        });

        // Dismiss button: Close and mark as dismissed for this session
        dismissBtn.addEventListener('click', () => this.dismiss());
    }

    /**
     * Start polling to check if user subscribed
     */
    startPolling() {
        console.log('🔄 Starting subscription polling...');
        let pollCount = 0;
        const maxPolls = 20; // Poll for 1 minute max (20 * 3 seconds)

        // 🔒 SECURITY FIX: Add 2-second delay before first check
        // This prevents race condition where website checks before bot saves subscription
        setTimeout(() => {
            this.pollingInterval = setInterval(async () => {
                pollCount++;
                console.log(`🔄 Poll attempt ${pollCount}/${maxPolls}`);

                const isSubscribed = await this.checkSubscriptionStatus(this.userPhone);

                if (isSubscribed) {
                    console.log('✅ User subscribed! Closing modal...');
                    this.showSuccessAndClose();
                    clearInterval(this.pollingInterval);
                } else if (pollCount >= maxPolls) {
                    console.log('⏱️ Polling timeout reached');
                    clearInterval(this.pollingInterval);
                }
            }, 3000); // Check every 3 seconds
        }, 2000); // Wait 2 seconds before starting polling
    }

    /**
     * Show success message and close modal
     */
    showSuccessAndClose() {
        if (this.modal) {
            const content = this.modal.querySelector('div > div');
            content.innerHTML = `
                <div style="text-align: center; padding: 20px;">
                    <div style="font-size: 60px; margin-bottom: 20px;">✅</div>
                    <h2 style="color: #4CAF50; font-family: 'Cairo', sans-serif; margin-bottom: 10px;">تم الاشتراك بنجاح!</h2>
                    <p style="color: #666; font-family: 'Cairo', sans-serif;">ستصلك الإشعارات على واتساب الآن</p>
                </div>
            `;

            setTimeout(() => this.close(), 2000);
        }
    }

    /**
     * Dismiss modal (user clicked "Maybe Later")
     */
    dismiss() {
        sessionStorage.setItem('whatsapp_prompt_dismissed', 'true');
        console.log('📝 Modal dismissed for this session');
        this.close();
    }

    /**
     * Close modal with animation
     */
    close() {
        if (this.modal) {
            this.modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                this.modal.remove();
                if (this.pollingInterval) {
                    clearInterval(this.pollingInterval);
                }
            }, 300);
        }
    }

    /**
     * Initialize and show modal if conditions are met
     */
    async init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.show());
        } else {
            this.show();
        }
    }

    /**
     * Show modal after delay and checks
     */
    async show() {
        // Small delay for better UX
        setTimeout(async () => {
            const canShow = await this.shouldShow();
            if (canShow) {
                this.create();
                this.attachEvents();
            }
        }, 3000);
    }
}

// Auto-initialize
const whatsappModal = new WhatsAppSubscriptionModal();
whatsappModal.init();
